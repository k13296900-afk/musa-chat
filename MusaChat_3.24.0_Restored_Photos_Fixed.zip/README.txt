Musa.Chat 3.23.0 — Deploya/Node deployment bundle

Entry page: index.html (served at / by server.js)
Backend: Node.js 20+, HTTP API + WebSocket at the same origin.
Start command: npm start
Health check: /api/health

Deploy settings:
- Runtime: Node.js 20+ (or Dockerfile)
- Build/install: npm install
- Start: npm start
- Port: use platform-provided PORT (server.js reads process.env.PORT)
- Persistent storage: mount a persistent volume for musa-chat-data.json, or set MUSA_DB_FILE to a writable persistent path.
- Add OPENAI_API_KEY as a server-side secret if you want server-backed musa AI. Never put API keys in index.html.
- HTTPS/WSS should be provided by the hosting platform/proxy.

Important limitations:
- This package includes an existing Musa.Chat WebSocket backend and the 3.23.0 front-end. It is a best-effort deployment bundle, not proof that every button/feature is fully integrated end-to-end. The front-end has some client-side and MQTT fallback logic; verify its transport configuration against the deployed backend.
- WebSocket payloads and media limits are configurable; very large base64 video messages can consume substantial memory. Use object storage + signed uploads for production-scale video hosting.
- Deploya product settings may differ by plan; configure the project to run a Node.js service or Docker container.
- Do not deploy with secrets inside the zip. Set environment variables in Deploya dashboard.
